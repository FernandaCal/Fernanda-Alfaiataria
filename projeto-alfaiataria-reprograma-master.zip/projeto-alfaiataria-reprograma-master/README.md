# projeto-alfaiataria-reprograma
projeto de site com tema do seriado "tempo entre costuras" .curso Front end, Reprograma - Bootstrap

Melhorias:
.itens dropdown nav, 
.pages nav,
.footer,
.imagens sem pixel zuado,
.link para blog,
.form do contato

